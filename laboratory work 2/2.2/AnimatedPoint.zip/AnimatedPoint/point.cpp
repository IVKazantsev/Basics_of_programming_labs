#include "point.h"

Point::Point()
    :Point(0,0,0)
{
}

Point::Point(int x, int y, int size)
    :x(x), y(y), size(size)
{
}

int Point::getX() const
{
    return x;
}

void Point::setX(int value)
{
    x = value;
}

int Point::getY() const
{
    return y;
}

void Point::setY(int value)
{
    y = value;
}

int Point::getSize() const
{
    return size;
}

void Point::setSize(int value)
{
    size = value;
}
