#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "point.h"
#include <QPainter>
#include <QMouseEvent>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    event;
    QPainter painter(this);
    for(int i = 0; i < n; i++)
    {
        //точка 1 пиксель, с каждой стороны еще по пикселю
        painter.drawLine(points[i]->getX() - (points[i]->getSize())/3,points[i]->getY(),points[i]->getX() + (points[i]->getSize())/3,points[i]->getY());
        painter.drawLine(points[i]->getX(),points[i]->getY() - (points[i]->getSize())/3,points[i]->getX(),points[i]->getY() + (points[i]->getSize())/3);
    }
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    Point *b = nullptr;
    if(n>=10) return;
    if (event->modifiers() & Qt::ShiftModifier)
        qDebug("ShiftModifier");
    else if (event->modifiers() & Qt::ControlModifier)
        qDebug("ControlModifier");
    else{
        qDebug("x=%d, y=%d",event->x(), event->y());
        b = new Point(event->x(),event->y(),3);
    }
    if(b)
        points[n++] = b;
    repaint();
}


