#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "point.h"
#include <QPainter>
#include <QPen>
#include <QMouseEvent>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    event;
    QPainter painter(this);
    for(int i = 0; i < points.size(); i++)
        {
            if(i >= 5) points[i]->setWidth(2);
            points[i]->setSize(i + 3);
            points[i]->draw(&painter);
            if (i > 0) {
                QPen pen;
                pen.setWidth(1);
                painter.setPen(pen);
                painter.drawLine(points[i-1]->getX(),points[i-1]->getY(),points[i]->getX(),points[i]->getY());
            }
        }
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    Point *b = nullptr;
    if (event->modifiers() & Qt::ShiftModifier)
        qDebug("ShiftModifier");
    else if (event->modifiers() & Qt::ControlModifier)
        qDebug("ControlModifier");
    else{
        qDebug("x=%d, y=%d",event->x(), event->y());
        b = new Point(event->x(),event->y());
    }
    if(b)
        points.append(b);
    repaint();
}


